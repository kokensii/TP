package tp.p1.PlantsVsZombies;

import java.util.Random;

public class Game {
	
	static final int DIMX = 4;
	static final int DIMY = 8;
	
	public SunflowerList sunflowerList;
	public PeashooterList peashooterList;
	public ZombieList zombieList;
	public SuncoinManager managerSuns;
	public ZombieManager managerZombie;
	private int contCycles;
	private Random aleatorio = new Random(System.currentTimeMillis());
	private Level level;
	//private GamePrinter gamePrinter; No hace falta
	
	public Game(Level level, Random rand) {
		this.level = level;
		this.contCycles = 0;
		initZombieList();
		initPeashooterList();
		initSunflowerList();
		initSuncoinManager();
		initZombieManager();
		//this.gamePrinter = new GamePrinter(this, 4, 8);
		this.aleatorio = rand;
	}
	
	public void update() {
		if(managerZombie.isZombieAdded()) {
			boolean added = false;
			do{
				int valorEntero = aleatorio.nextInt(4);
				if(isEmpty(valorEntero, 7)){
					Zombie z = new Zombie(valorEntero,7,this); //para que lo meta en la ultima fila 
					this.zombieList.add(z);
					added = true;
				}
			}while(!added);
		}
		
		sunflowerList.update();
		peashooterList.update();
		zombieList.update();
		
		for(int i = 0; i < DIMX; i++) {
			for(int j = 0; j < DIMY; j++) {
				gamePrinter.getBoard()[i][j] = drawBoard(i, j);
			}
		}
		
		this.contCycles++;
	}
	
	public int getContCycles() {
		return contCycles;
	}

	public void setContCycles(int contCycles) {
		this.contCycles = contCycles;
	}

	public Level getLevel() {
		return level;
	}

	public void setLevel(Level level) {
		this.level = level;
	}
	
	public String toString() {  // este metodo llamara al gameprinter para dibujar el tablero 
		String cadena = "";
		GamePrinter gp = new GamePrinter(this, 4, 8);
		if(this.contCycles == 0) cadena = "Random seed used: " + "2"/*poner seed*/ + "\n";
		cadena += "Number of cycles: " + this.contCycles + "\n" +
				  "Sun coins: " + this.managerSuns.getSunCoins() + "\n" +
				  "Remaining zombies: " + this.managerZombie.getNumZombies() + "\n" +
				  gp.toString();
		return cadena;
	}
	
	public boolean isEmpty(int x, int y) {
		if(!peashooterList.isPeashooter(x, y) && !sunflowerList.isSunflower(x, y) &&
			!zombieList.isZombie(x, y)) return true;
		return false;
	}
	
	public boolean isZombie(int x, int y) {//Comprobamos si en la posicion x, y se encuentra un zombie
		if(zombieList.isZombie(x, y)) return true;
		return false;
	}
	
	public boolean isPeashooter(int x, int y) {//Comprobamos si en la posicion x, y se encuentra un peashooter
		if(peashooterList.isPeashooter(x, y)) return true;
		return false;
	}
	
	public boolean isSunflower(int x, int y) {//Comprobamos si en la posicion x, y se encuentra un sunflower
		if(sunflowerList.isSunflower(x, y)) return true;
		return false;
	}
	
	private void initPeashooterList() {
		this.peashooterList = new PeashooterList();
	}
	
	private void initSunflowerList() {
		this.sunflowerList = new SunflowerList();
	}
	
	private void initZombieList() {
		this.zombieList = new ZombieList();
	}
	
	private void initSuncoinManager() {
		this.managerSuns = new SuncoinManager();
	}
	
	private void initZombieManager() {
		this.managerZombie = new ZombieManager(level, this.aleatorio);
	}
	
	public String drawBoard(int x, int y) {
			if(zombieList.isZombie(x,y))
				return zombieList.getZombie(zombieList.indexZombie(x, y)).toString();
			
			if(peashooterList.isPeashooter(x, y)) {
				return peashooterList.getPeashooter(peashooterList.indexPeashooter(x, y)).toString();
				}
			
			if(sunflowerList.isSunflower(x, y)) {
				return sunflowerList.geetSunflower(sunflowerList.indexSunflower(x, y)).toString();
				}
			else {
				return " ";
			}
	}
	
	public boolean loseGame() {
		boolean fin = false;
		for(int i = 0; i < 4 && !fin ;i++) {
			if(isZombie(i,0)) {
				fin = true;
			}
		}
		return fin;
	}
	
	public boolean winGame() { 
		boolean fin = false;
		if(managerZombie.getNumZombies()== 0) {
			int numzombies = 0;
			for (int i = 0; i < DIMX; i++) {
				for(int j = 0; j < DIMY; j++) {
					if(isZombie(i, j)) {
						numzombies++;
					}
				}
			}
			fin = (numzombies == 0) ? true : false;
		}
		return fin;
	}
	
	public void resetGame() {
		initZombieList();
		initPeashooterList();
		initSunflowerList();
		initSuncoinManager();
		initZombieManager();
		this.contCycles = 0;
		GamePrinter gp = new GamePrinter(this, 4, 8);
		System.out.println(toString());
	}
	
}
